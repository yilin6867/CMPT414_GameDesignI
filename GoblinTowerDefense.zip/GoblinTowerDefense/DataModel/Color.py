
class Color():
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    GREEN = (90, 230, 10)
    BLACK_TRANS = (0, 0, 0, 127)
    GRAY = (128, 128, 128)
    RED = (255, 0, 0)
